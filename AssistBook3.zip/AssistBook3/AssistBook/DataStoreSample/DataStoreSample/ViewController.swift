//
//  ViewController.swift
//  DataStoreSample
//
//  Created by kenny on 2019/08/16.
//  Copyright © 2019 kenny. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var nameTextFIeld: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.textField.delegate = self
        self.nameTextFIeld.delegate = self
    }

    @IBAction func didTapSave(_ sender: UIButton) {
        
        let text = textField.text
        let name = nameTextFIeld.text
        let post = Post()
        
        // 保存するデータを作成する
        post.text = text ?? ""
        post.authorName = name ?? "No Name"
        post.createdAt = Date()
        
        PostRepository.shared.add(post: post)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

