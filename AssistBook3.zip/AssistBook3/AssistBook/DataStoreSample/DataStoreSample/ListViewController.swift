//
//  ListViewController.swift
//  DataStoreSample
//
//  Created by Kenny on 2019/08/16.
//  Copyright © 2019 kenny. All rights reserved.
//

import UIKit

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var posts = [Post]()
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // 保存したデータを読み込み
        self.posts = PostRepository.shared.get()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell()
        let post = self.posts[indexPath.row]
        
        cell.textLabel?.text = "\(post.authorName): \(post.text)"
        
        return cell
    }

}
