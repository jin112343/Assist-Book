//
//  siori.swift
//  AssistBook
//
//  Created by Jin Mizou on 2019/08/25.
//  Copyright © 2019 Jin Mizou. All rights reserved.
//

import UIKit

class SioriController: UIViewController, UITextFieldDelegate  {
    @IBAction func tapView(_ sender: UITapGestureRecognizer) {
                view.endEditing(true)
    }
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var nameTextFIeld: UITextField!
    
    
    @IBAction func didTapSave(_ sender: UIButton) {
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        view.endEditing(true)
        return true
    }
}
