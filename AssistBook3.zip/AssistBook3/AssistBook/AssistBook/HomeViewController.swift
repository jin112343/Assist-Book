//
//  ViewController.swift
//  AssistBook
//
//  Created by Jin Mizou on 2019/08/24.
//  Copyright © 2019 Jin Mizou. All rights reserved.
//

import UIKit

class HomeController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

