//
//  ListViewController.swift
//  DataStoreSample
//
//  Created by Kenny on 2019/08/16.
//  Copyright © 2019 kenny. All rights reserved.
//

import UIKit

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITableView {
    

    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
