//
//  Post.swift
//  DataStoreSample
//
//  Created by Kenny on 2019/08/16.
//  Copyright © 2019 kenny. All rights reserved.
//

import RealmSwift

// 保存したいデータ領域の頭に「@objc dynamic」をつける。
// @objc dynamic というのはお作法として決まっているので、
// 理由は特に知る必要はありません
// 詳しくは RealmSwiftの公式サイトをご覧ください。
class Post: Object {
    @objc dynamic var text = ""
    @objc dynamic var authorName = ""
    @objc dynamic var createdAt: Date?
}
