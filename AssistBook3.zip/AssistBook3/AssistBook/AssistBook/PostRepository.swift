//
//  PostRepository.swift
//  DataStoreSample
//
//  Created by kenny on 2019/08/16.
//  Copyright © 2019 kenny. All rights reserved.
//

import Foundation
import RealmSwift

class PostRepository: NSObject {
    // シングルトンという設計の定石を使っています。
    // こうすることで、このクラス（PostRepotitory）のインスタンスを１個に限定し、それを使いまわすことができます。
    // 詳しくは「シングルトン　デザインパターン」などでググってみてください。
    static let shared = PostRepository()
    private var realm: Realm!
    
    override init() {
        super.init()
        self.realm = try! Realm()
    }
    
    // Postデータ一覧を配列で取得する
    func get() -> [Post] {
        
        let posts = Array(self.realm.objects(Post.self))
        
        return posts
    }
    
    // Postデータを追加で保存する
    func add(post: Post) {
        
        try! self.realm.write {
            // realm.write の中で行わないと、エラーになるので注意！
            post.createdAt = Date()
            realm.add(post)
        }
    }
    
    // Postデータの内容を更新する
    func update(post: Post, text: String) {
        
        try! self.realm.write {
            // realm.write の中で行わないと、エラーになるので注意！
            post.text = text
        }
    }
}


